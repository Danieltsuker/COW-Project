from django.apps import AppConfig


class CowConfig(AppConfig):
    name = 'COW'
