from django.template.defaultfilters import register, stringfilter


@register.filter
@stringfilter
def rmv_underscores(value):
    value = value.replace('_', ' ')
    return value.title()
