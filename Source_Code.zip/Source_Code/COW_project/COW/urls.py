from django.urls import path
from .views import PostListView, \
    PostDetailView, \
    PostCreateView, \
    PostUpdateView, \
    PostDeleteView, \
    UserPostListView
from . import views

urlpatterns = [
    # Here we get an empty path, the function we created
    # that returns that HTTP response that we are on the
    # name-page and the name of the path (not generic).
    path('', views.welcome, name='cow-welcome'),

    # This is what we have for all of the paths (naming
    # path, instead of the empty path, because we are
    # already in the website).
    path('home/', views.home, name='cow-home'),

    # # # #

    # The blog/ path takes the users to a blog, where registered
    # users can ask and answer each other on topics, about the
    # attacks.
    path('blog/', PostListView.as_view(), name='cow-blog'),
    path('user/<str:username>', UserPostListView.as_view(), name='user-posts'),
    path('post/<int:pk>/', PostDetailView.as_view(), name='post-detail'),
    path('post/new/', PostCreateView.as_view(), name='post-create'),
    path('post/<int:pk>/update/', PostUpdateView.as_view(), name='post-update'),
    path('post/<int:pk>/delete/', PostDeleteView.as_view(), name='post-delete'),
    path('about/', views.about, name='cow-about'),
]
