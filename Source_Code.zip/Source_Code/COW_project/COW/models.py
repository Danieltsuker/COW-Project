from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils import timezone
from users.models import Profile


# Each class is an own table in the database. Here we declare
# the attacks table, named Attack.
class Attack(models.Model):
    # Each attribute will be a different field in the database
    title = models.CharField(max_length=25)  # A char field of a max length of 25
    content = models.TextField()  # Enable lines and lines of text

    # A dander method, which is going to return the title of
    # a current Attack object.
    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('attack-detail', kwargs={'pk': self.pk})


# Since we are going to have a blog, where users will able to
# ask and answer each other about the attacks, we need to have
# a Post class. It is an own table in the database.
class Post(models.Model):
    # Each attribute will be a different field in the database
    title = models.CharField(max_length=100)  # A char field of a max length of 100
    content = models.TextField()  # Enable lines and lines of text
    # Every time the post was updated, the data also:
    date_posted = models.DateTimeField(default=timezone.now)
    # If a user is deleted, his posts gonna be deleted too.
    # But, delete a post - does not mean delete the user too
    # (it is an "one-way street").
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    comment_count = models.IntegerField(default=0)

    # A dander method, which is going to return the title of
    # a current Post object.
    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('post-detail', kwargs={'pk': self.pk})


# This class represents a comment (or comments), each user can write
# on any post (as answer or continuing of discussion).
class Comment(models.Model):
    # Here we have a foreign key, which establishes a many-to-one
    # relationship with the Post model, since every comment will
    # be made on a post and each post will have multiple comments.
    # In addition - when a post is deleted, all of its comments will
    # be deleted too.
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    # The learning of the author of the comment
    name = models.CharField(max_length=80)
    email = models.EmailField()
    # The learning of the comment.
    body = models.TextField()  # Content
    created_on = models.DateTimeField(auto_now_add=True)
    active = models.BooleanField(default=False)

    # We are ordering our comments by the date, they were created.
    class Meta:
        ordering = ['created_on']

    def __str__(self):
        return 'Comment {} by {}'.format(self.body, self.name)

    def get_absolute_url(self):
        return reverse('post-detail', kwargs={'pk': self.post.pk})


####################################################
