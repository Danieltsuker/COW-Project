from django.contrib import admin
from .models import Post, Comment

admin.site.register(Post)


# This way we registers the comment into the admin area.
@admin.register(Comment)
# The class allows us to customizes the representation
# of data on the screen.
class CommentAdmin(admin.ModelAdmin):
    list_display = ('name', 'body', 'post', 'created_on', 'active')
    list_filter = ('active', 'created_on')
    search_fields = ('name', 'email', 'body')
    actions = ['approve_comments']

    # With this function we can approving many comment
    # objects at once.
    def approve_comments(self, request, queryset):
        queryset.update(active=True)
