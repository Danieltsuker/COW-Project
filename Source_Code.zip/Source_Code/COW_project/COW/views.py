from django.shortcuts import get_object_or_404
from django.contrib.auth.mixins import LoginRequiredMixin, \
    UserPassesTestMixin
from django.contrib.auth.models import User
from django.views.generic import ListView, \
    DetailView, \
    CreateView, \
    UpdateView, \
    DeleteView
from .forms import CommentForm
from .models import Attack, Post, Comment
from django.shortcuts import render, redirect


# The welcome function is actually opens the first page
# a user sees, when connects to the website. It gets a
# request argument and returns a response, of what we
# want the user to see on the screen.
def welcome(request):
    return render(request, 'COW/welcome.html')


# The home function handles the traffic from the homepage
# of our website. It gets a request argument and returns
# a response, of what we want the user to see on the
# screen.
def home(request):
    # This is a dictionary, with which we can pass that
    # data into our html template. The data is from our
    # database.
    context = {
        'attacks': list(Attack.objects.all())
    }
    # Returns a HTTP response (or an exception)
    return render(request, 'COW/home.html', context)


# An About view
def about(request):
    return render(request, 'COW/about.html')


#############################

#############################


class AttackListView(ListView):
    model = Attack
    template_name = 'COW/home.html'
    context_object_name = 'attacks'
    # Let us order the attacks, in an alphabetic order.
    ordering = ['-title']


class AttackDetailView(DetailView):
    model = Attack
    # template_name = 'COW/attacks/bases/learning_base.html'


class PostListView(ListView):
    model = Post
    template_name = 'COW/blog.html'
    context_object_name = 'posts'
    # Let us order the posts, so we see firstly the last one.
    ordering = ['-date_posted']
    paginate_by = 8


class UserPostListView(ListView):
    model = Post
    template_name = 'COW/user_posts.html'
    context_object_name = 'posts'
    paginate_by = 8

    def get_queryset(self):
        user = get_object_or_404(User, username=self.kwargs.get('username'))
        return Post.objects.filter(author=user).order_by('-date_posted')


class PostDetailView(DetailView):
    model = Post

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['comments'] = Comment.objects.all()[::-1]
        context['comm_form'] = CommentForm()
        return context

    def post(self, request, *args, **kwargs):
        if request.method == 'POST':
            comm_form = CommentForm(request.POST)
            comm_form.instance.post = Post.objects.get(id=self.kwargs.get('pk'))
            comm_form.instance.author = self.request.user
            comm_form.save()
            return redirect('post-detail', pk=self.kwargs.get('pk'))
        else:
            return redirect('post-detail', pk=self.kwargs.get('pk'))


class PostCreateView(LoginRequiredMixin, CreateView):
    model = Post
    fields = ['title', 'content']

    # To post something we need to be logged in
    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)


class PostUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Post
    fields = ['title', 'content']

    # To post something we need to be logged in
    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    # Prevent any users from trying update other people's posts
    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False


class PostDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Post
    success_url = '/blog'

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False
