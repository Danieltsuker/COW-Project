from django.db import models
from django.contrib.auth.models import User
from PIL import Image
from django.utils import timezone
import COW_project.settings as config


class Profile(models.Model):
    # One user has one profile, and one profile belongs to one user
    # And, if the user is deleted - delete the profile also
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    image = models.ImageField(default='user.png', upload_to='profile_pics')

    def __str__(self):
        return f'{self.user.username} Profile'

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)

        # Opens the current image
        img = Image.open(self.image.path)

        # If the image is too large, let's resize it
        if img.height > 100 or img.width > 100:
            output_size = (100, 100)
            img.thumbnail(output_size)
            img.save(self.image.path)


class FormerPasswords(models.Model):
    username = models.CharField(max_length=100)
    former_password = models.CharField(max_length=100)
    insert_time = models.DateTimeField(default=timezone.now)

    def _str_(self):
        return f'{self.username}, Former password: {self.former_password}'

    def save(self, *args, **kwargs):
        number_of_former_passwords =\
            FormerPasswords.objects.filter(username=self.username).count()

        if number_of_former_passwords >= config.NUM_OF_FORMER_PASSWORDS_TO_STORE:
            to_delete = \
                FormerPasswords.objects.filter(username=self.username).order_by('insert_time').first()

            # Delete the first inserted password of this user
            to_delete.delete()

        # Save the new former password
        super().save(*args, **kwargs)
