from django.contrib.auth import update_session_auth_hash, authenticate, login as login_user
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .forms import UserRegisterForm, UserUpdateForm, ProfileUpdateForm, OurPasswordChangeForm, LoginForm
from .login_handle import InvalidLoginAttemptsCache
import COW_project.settings as config
import arrow


# Creating a register view
def register(request):
    if request.method == 'POST':
        # Creating a form, in case of post request
        form = UserRegisterForm(request.POST)
        # If the data is valid
        if form.is_valid():
            # It is also automatically hashes the password
            form.save()
            messages.success(request, f'Your account has been created! You are now able to log in!')
            return redirect('login')
    else:
        # Creating a blank form
        form = UserRegisterForm()
    return render(request, 'users/register.html', {'form': form})


# Makes sure a user is logged in, before can access this page
@login_required
def profile(request):
    user = request.user
    if request.method == 'POST':
        u_form = UserUpdateForm(request.POST, instance=user)
        p_form = ProfileUpdateForm(request.POST,
                                   request.FILES,
                                   instance=user.profile)
        # We gonna save the data only in case the both forms are valid
        if u_form.is_valid() and p_form.is_valid():
            u_form.save()
            p_form.save()
            messages.success(request, f'Your account has been updated!')
            return redirect('profile')
    else:
        u_form = UserUpdateForm(instance=user)
        p_form = ProfileUpdateForm(instance=user.profile)

    context = {
        'u_form': u_form,
        'p_form': p_form
    }

    return render(request, 'users/profile.html', context)


def password_change(request):
    if request.method == 'POST':
        form = OurPasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Your password was successfully updated!')
            return redirect('password_change')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = OurPasswordChangeForm(request.user)
    return render(request, 'users/password_change.html', {
        'form': form
    })


# Creating the login view
def login(request):
    if request.method == 'POST':
        # Creating a form, in case of post request
        form = LoginForm(request.POST)

        username = request.POST.get('username')
        password = request.POST.get('password')

        print('A user with username = ' + username + ' is trying to login!')
        cache_results = InvalidLoginAttemptsCache.get(username)

        if cache_results and cache_results.get('lockout_start'):
            # user was in lockout
            # get the lockout start time
            lockout_start = arrow.get(cache_results.get('lockout_start'))

            # True if the user should be still in lockout
            locked_out = lockout_start >= arrow.utcnow().shift(minutes=-config.LOCKOUT_TIME)

            if not locked_out:
                # the lockout is now deleted
                print('user: ' + username + ' is no longer in lockout')
                InvalidLoginAttemptsCache.delete(username)
                the_user = authenticate(username=username, password=password)

                if the_user is not None:
                    print('the user ' + the_user.username + ' is a real user')
                    login(the_user)
                    return redirect('cow-home')
                else:
                    print('not a real user')
                    form.add_error("username", "Wrong username or password...")
                    return render(request, 'users/login.html', {'form': form})
            else:
                # still in lockout
                print('user: ' + username + ' is still in lockout')
                # Add an error to the form to let the user know they're locked out and can't log in.
                # Code to do this will vary depending on whether you're in a view or
                # the form class itself
                form.add_error("username", "Try again later...")
                return render(request, 'users/login.html', {'form': form})
        else:
            print('user: ' + username + ' is not in lockout')

            # If they don't have an entry in the cache, we know they're not locked out,
            # and we can process their request
            the_user = authenticate(username=username, password=password)

            if the_user is not None:
                # it is a normal login flow
                print('the user ' + the_user.username + ' is a real user')
                login_user(request, the_user)
                return redirect('cow-home')
            else:
                print('not a real user')
                form.add_error("username", "Wrong username or password...")
                cache_results = InvalidLoginAttemptsCache.get(username)
                lockout_timestamp = None
                now = arrow.utcnow()
                invalid_attempt_timestamps = cache_results['invalid_attempt_timestamps'] if cache_results else []

                # clear any invalid login attempts from the timestamp bucket that were longer ago than the range
                invalid_attempt_timestamps = [timestamp for timestamp in invalid_attempt_timestamps if
                                              timestamp > now.shift(minutes=-config.LOCKOUT_TIME).timestamp]

                # add this current invalid login attempt to the timestamp bucket
                invalid_attempt_timestamps.append(now.timestamp)
                # check to see if the user has enough invalid login attempts to lock them out
                if len(invalid_attempt_timestamps) >= config.LOCKOUT_ATTEMPTS:
                    lockout_timestamp = now.timestamp
                    # This is also where you'll need to add an error to the form to both prevent their
                    # successful authentication and let the user know
                # Add a cache entry. If they've already got one, this will overwrite it, otherwise it's a new one
                InvalidLoginAttemptsCache.set(username, invalid_attempt_timestamps, lockout_timestamp)
                return render(request, 'users/login.html', {'form': form})
    else:
        form = LoginForm()

        return render(request, 'users/login.html', {'form': form})
