from django.apps import AppConfig


# Need to add this to project settings
class UsersConfig(AppConfig):
    name = 'users'

    def ready(self):
        import users.signals