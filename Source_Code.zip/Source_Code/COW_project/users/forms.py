from django import forms
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, PasswordChangeForm
from .models import Profile, FormerPasswords


class LoginForm(forms.Form):
    """Simple login form"""
    username = forms.CharField(max_length=100)
    password = forms.CharField(max_length=100, widget=forms.PasswordInput)


# Inherits from UserCreationForm
class UserRegisterForm(UserCreationForm):
    # Adding fields to the form
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

    username = forms.CharField(
        widget=forms.TextInput(
            attrs={'class': 'form-control', 'placeholder': 'Daniel'}
        )
    )

    email = forms.CharField(
        widget=forms.TextInput(
            attrs={'class': 'form-control', 'placeholder': 'test@gmail.com'}
        )
    )


# A ModelForm allows us to create a form that work with specific
# form in the database.
class UserUpdateForm(forms.ModelForm):
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'email']  # update username and email


class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['image']  # update the image


class OurPasswordChangeForm(PasswordChangeForm):
    def is_valid(self):
        the_user = self.user
        the_new_password = self.data['new_password1']
        the_new_hashed_password = make_password(the_new_password)

        print('the user: ' + the_user.username)
        print('the new password: ' + the_new_password)
        print('the new password: ' + the_new_hashed_password)

        answer = super().is_valid() and self.validate(the_new_hashed_password, the_user)

        if answer is True:
            former_password_to_add = FormerPasswords(username=the_user.username, former_password=the_user.password)
            former_password_to_add.save()

        return answer

    def validate(self, new_password, user):
        former_passwords = FormerPasswords.objects.filter(username=user.username)
        current_password = user.password

        if new_password in former_passwords:
            return False

        if new_password is current_password:
            return False

        return True

    def get_help_text(self):
        return "Your password can't be one of your 3 former passwords"