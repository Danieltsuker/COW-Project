from django.contrib import admin
from .models import Profile

# Allows the admin to see the profiles also
admin.site.register(Profile)
