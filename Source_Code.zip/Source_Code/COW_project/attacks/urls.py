from django.urls import path
from .views import DummyPostListView, DummyPostDetailView, DummyPostCreateView, DummyPostDeleteView
from . import views

urlpatterns = [
    path('hacker/', views.hacker, name='hacked'),

    path('attacks/xss/dom/search/', views.searchView, name='xss-dom-search'),
    path('attacks/xss/dom/select/', views.selectedView, name='xss-dom-select'),
    path('attacks/xss/dom/search/fail/', views.searchViewFailing, name='xss-dom-search-fail'),
    path('attacks/xss/dom/select/fail/', views.selectedViewFailing, name='xss-dom-select-fail'),

    path('attacks/SQL-injection/dummy-registration/', views.dummyRegistrationFormView, name='dummy-registration'),

    path('attacks/xss/stored/dummy-blog/', DummyPostListView.as_view(), name='dummy-blog'),
    path('attacks/xss/stored/dummy-post/<int:pk>/', DummyPostDetailView.as_view(), name='dummy-post-detail'),
    path('attacks/xss/stored/dummy-post/new/', DummyPostCreateView.as_view(), name='dummy-post-create'),
    path('attacks/xss/stored/dummy-post/<int:pk>/delete/', DummyPostDeleteView.as_view(), name='dummy-post-delete'),

    # In order to get any attack page, the url is going to be
    # .../attack/title/ - when the title has to be a string.
    # The title is our primary key, and this way we can
    # understand which attack, we are dealing with.

    path('attack/<str:attack_title>/learn/', views.learn, name='attack-detail'),

    path('attack/<str:attack_title>/perform/', views.perform, name='attack-perform'),

    path('attack/<str:attack_title>/defend/', views.defend, name='attack-defend'),

    path('attack/<str:attack_title>/fail_to_attack/', views.attack_with_defence_on, name='attack-fail'),

    path('attacks/csrf/login', views.csrfLoginView, name='csrf-login'),
    path('attacks/csrf/logout', views.csrfLogoutView, name='csrf-logout'),
    path('attacks/csrf/email-update', views.emailUpdate, name='csrf-email-update'),
]
