from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils import timezone
from users.models import Profile


class UserAttack(models.Model):
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=150)
    salt = models.CharField(max_length=150)

    class Meta:
        db_table = 'login_table'

    def __str__(self):
        return self.username


class City(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name


class DummyPost(models.Model):
    # Each attribute will be a different field in the database
    title = models.CharField(max_length=100)  # A char field of a max length of 100
    content = models.TextField()  # Enable lines and lines of text
    # Every time the post was updated, the data also:
    date_posted = models.DateTimeField(default=timezone.now)
    # If a user is deleted, his posts gonna be deleted too.
    # But, delete a post - does not mean delete the user too
    # (it is an "one-way street").
    author = models.ForeignKey(User, on_delete=models.CASCADE)

    # A dander method, which is going to return the title of
    # a current Post object.
    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('dummy-post-detail', kwargs={'pk': self.pk})


class UserDetails(models.Model):
    name = models.CharField(max_length=100)
    lastName = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    phoneNumber = models.CharField(max_length=100)

    class Meta:
        db_table = 'users_information'

    def __str__(self):
        return ' name= ' + self.name + '\n lastName= ' + self.lastName + '\n city= ' + self.city + '\n phoneNumber=' + self.phoneNumber
