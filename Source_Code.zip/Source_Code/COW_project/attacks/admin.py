from django.contrib import admin
from COW.models import Attack
from attacks.models import *

# Register your models here.
admin.site.register(Attack)
admin.site.register(UserAttack)
admin.site.register(UserDetails)
admin.site.register(City)
