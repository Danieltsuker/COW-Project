from django.apps import AppConfig


class AttacksConfig(AppConfig):
    name = 'attacks'
