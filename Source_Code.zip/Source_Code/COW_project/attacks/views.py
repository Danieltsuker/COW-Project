import hashlib
import os

from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, ListView, DetailView, DeleteView

from .forms import UserUpdateForm
from .models import UserAttack, City, DummyPost
from COW.models import Attack
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.db import connection


# # # THE ATTACK VIEWS # # #
############################

# # #SQL INJECTION # # #

def dummyRegistrationFormView(request):
    context = {}
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        userexists = UserAttack.objects.filter(username=username).exists()
        if userexists or (username == 'aaa' and password == 'aaa'):
            status = "User already exists"
        else:
            status = "User created successfully"
            salt = os.urandom(32).hex()
            key = hmac_method(password, salt)
            user = UserAttack(username=username, password=key, salt=salt)
            user.save()
        context['status'] = status

    return render(request, 'attacks/dummy_user.html', context)


def hmac_method(password, salt):
    key = hashlib.pbkdf2_hmac(
        'sha256',  # the hash digest algorithm for HMAC
        password.encode('utf-8'),  # convert the password to bytes
        salt.encode('utf-8'),  # the random salt for the Hash
        100000  # 100,000 iteration of SHA-256
    )
    return key.hex()


# # #SQL INJECTION # # #

def sqlInjectionloginView(request, the_attack):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        userexists = UserAttack.objects.filter(username=username).exists()
        if userexists:
            salt = UserAttack.objects.get(username=username).salt
        else:
            salt = '0'
        hashpwd = hmac_method(password, salt)
        people = list(UserAttack.objects.raw(
            "SELECT id,username,password FROM login_table WHERE username='" + username + "' and password='" + hashpwd +
            "'LIMIT 1"))

        if len(people) == 0:
            status = 'wrong username or password'
        else:
            status = 'you are login'
        return render(request, 'attacks/performing/SQL_Injection_performing.html',
                      {'object': the_attack, 'status': status})

    return render(request, 'attacks/performing/SQL_Injection_performing.html',
                  {'object': the_attack})


def sqlInjectionloginViewFailing(request, the_attack):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        people = UserAttack.objects.raw(
            'SELECT id,username,password FROM login_table WHERE username= %s and password=%s LIMIT 1',
            [username, password])

        if len(people) == 0:
            status = 'wrong username or password'
        else:
            status = 'you are login'
        return render(request, 'attacks/failing/SQL_Injection_failing.html',
                      {'object': the_attack, 'status': status})

    return render(request, 'attacks/failing/SQL_Injection_failing.html',
                  {'object': the_attack})


# # # ADVANCED SQL INJECTION # # #

def complexSqlInjection(request, the_attack):
    print('in the advanced sql attack')
    context = {'object': the_attack}

    if request.method == 'POST':
        search = request.POST.get('username')
        if ("delete" in search) or ("Delete" in search) or ("DELETE" in search) or ("DROP" in search)\
                or ("Drop" in search) or ("drop" in search):
            context['search'] = "Not allowed query..."
            return render(request, 'attacks/performing/Advanced_SQL_Injection_performing.html', context)
        cursor = connection.cursor()
        cursor.execute("SELECT name,city FROM users_information WHERE name='" + search + "' ")
        row = cursor.fetchall()
        print(row)
        context['row'] = row
        context['search'] = search

    return render(request, 'attacks/performing/Advanced_SQL_Injection_performing.html', context)


def complexSqlInjectionFailing(request, the_attack):
    print('in the advanced sql attack failing')
    context = {'object': the_attack}

    if request.method == 'POST':
        search = request.POST.get('username')
        cursor = connection.cursor()
        cursor.execute("SELECT name,city  FROM users_information WHERE name=%s", [search])
        row = cursor.fetchall()
        print(row)
        context['row'] = row
        context['search'] = search

    return render(request, 'attacks/failing/Advanced_SQL_Injection_failing.html', context)


# # # XSS REFLECTED # # #
def xssReflectedFormView(request, the_attack):
    context = {'object': the_attack, 'defence': 'off'}

    if 'q' in request.GET:
        q = request.GET['q']
        context['query'] = q

    return render(request, 'attacks/performing/XSS_Reflected_performing.html', context)


def xssReflectedFormViewFailing(request, the_attack):
    context = {'object': the_attack, 'defence': 'on'}

    if 'q' in request.GET:
        q = request.GET['q']
        context['query'] = q

    return render(request, 'attacks/failing/XSS_Reflected_failing.html', context)


# # # CSRF # # #
'''@csrf_exempt
def csrf(request):
    return render(request, 'attacks/csrf.html')'''


@csrf_exempt
def csrfLoginView(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            the_attack = Attack.objects.get(title='CSRF')

            return render(request, 'attacks/performing/CSRF_performing.html',
                          {'user': user, 'object': the_attack})

    else:
        form = AuthenticationForm()
    return render(request, 'attacks/other/CSRF/csrf_login.html', {'form': form})


@login_required(login_url='csrf-login')
@csrf_exempt
def csrfLogoutView(request):
    if request.method == 'POST':
        logout(request)
        the_attack = Attack.objects.get(title='CSRF')

        return render(request, 'attacks/performing/CSRF_performing.html',
                      {'object': the_attack})


@login_required(login_url='csrf-login')
@csrf_exempt
def emailUpdate(request):
    if request.method == 'POST':
        u_form = UserUpdateForm(request.POST, instance=request.user)
        if u_form.is_valid():
            u_form.save()
            the_attack = Attack.objects.get(title='CSRF')

            return render(request, 'attacks/performing/CSRF_performing.html',
                          {'object': the_attack})
    else:
        u_form = UserUpdateForm(instance=request.user)
    context = {
        'u_form': u_form,
    }
    return render(request, 'attacks/other/CSRF/csrf_email_update.html', context)


@csrf_exempt
def hacker(request):
    return render(request, 'attacks/other/CSRF/csrf_hacked.html')


# function getting a query set base on a particular search
def get_city_querySet(query=None):
    queryset = []
    queries = query.split(" ")  # for example = [for, example]
    for q in queries:
        cities = City.objects.filter(
            Q(name__icontains=q)
        ).distinct()
    for city in cities:
        queryset.append(city)
    return list(set(queryset))


# # # XSS DOM # # #

@csrf_exempt
def searchView(request):
    context = {}
    query = str("")
    if request.GET:
        query = request.GET['q']
        context['query'] = str(query)
    cities_found = get_city_querySet(query)
    context['cities'] = cities_found
    context['defence'] = 'off'
    return render(request, 'attacks/other/XSS/xss_dom_search.html', context)


@csrf_exempt
def searchViewFailing(request):
    context = {}
    query = str("")
    if request.GET:
        query = request.GET['q']
        context['query'] = str(query)
    cities_found = get_city_querySet(query)
    context['cities'] = cities_found
    context['defence'] = 'on'
    return render(request, 'attacks/other/XSS/xss_dom_search.html', context)


def selectedView(request):
    context = {'defence': 'off'}
    if request.GET:
        selectId = request.GET['selectId']
        context['selectId'] = selectId

    return render(request, 'attacks/other/XSS/xss_dom_select.html', context)


def selectedViewFailing(request):
    context = {'defence': 'on'}
    if request.GET:
        selectId = request.GET['selectId']
        context['selectId'] = selectId

    return render(request, 'attacks/other/XSS/xss_dom_select.html', context)


##############################################


class DummyPostListView(LoginRequiredMixin, ListView):
    model = DummyPost
    template_name = 'attacks/other/XSS/xss_blog.html'
    context_object_name = 'posts'
    # Let us order the posts, so we see firstly the last one.
    ordering = ['-date_posted']

    """def get_queryset(self):
        # user = get_object_or_404(User, username=self.kwargs.get('username'))
        user = get_object_or_404(User, username=self.request.user.username)
        # user_name = User.get_username()
        # user = User.objects.get(username=user_name)

        return DummyPost.objects.filter(author=user).order_by('-date_posted')
"""


class DummyPostDetailView(LoginRequiredMixin, DetailView):
    model = DummyPost

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        return context

    def post(self, request, *args, **kwargs):
        return redirect('dummy-post-detail', pk=self.kwargs.get('pk'))


class DummyPostCreateView(LoginRequiredMixin, CreateView):
    model = DummyPost
    fields = ['title', 'content']

    # To post something we need to be logged in
    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)


class DummyPostDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = DummyPost

    def get_success_url(self):
        return reverse_lazy('dummy-blog')

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False


'''def delete_all_dummy_posts(request):
    DummyPost.objects.all().delete()
    return redirect(request, 'attacks/other/XSS/xss_blog.html')'''

##############################################


special_attacks_perform = {
    'SQL_Injection': sqlInjectionloginView,
    'Advanced_SQL_Injection': complexSqlInjection,
    'XSS_Reflected': xssReflectedFormView
}

special_attacks_fail = {
    'SQL_Injection': sqlInjectionloginViewFailing,
    'Advanced_SQL_Injection': complexSqlInjectionFailing,
    'XSS_Reflected': xssReflectedFormViewFailing
}


##############################################


def learn(request, attack_title):
    obj = Attack.objects.get(title=attack_title)

    context = {
        'object': obj
    }

    return render(request, 'attacks/learning/' + attack_title + '_learning.html', context)


def perform(request, attack_title):
    print('in the perform')
    the_attack = Attack.objects.get(title=attack_title)

    if the_attack.title in special_attacks_perform.keys():
        print('inside the if')
        return special_attacks_perform[the_attack.title](request, the_attack)

    else:
        context = {
            'object': the_attack
        }

        return render(request, 'attacks/performing/' + attack_title + '_performing.html', context)


def defend(request, attack_title):
    obj = Attack.objects.get(title=attack_title)

    context = {
        'object': obj
    }

    return render(request, 'attacks/defending/' + attack_title + '_defending.html', context)


def attack_with_defence_on(request, attack_title):
    the_attack = Attack.objects.get(title=attack_title)

    if the_attack.title in special_attacks_fail.keys():
        print('inside the if')
        return special_attacks_fail[the_attack.title](request, the_attack)

    context = {
        'object': the_attack
    }

    return render(request, 'attacks/failing/' + attack_title + '_failing.html', context)
